﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task11
{
    class Program
    {
        static void Main(string[] args)
        {
            Equation Lin = new Equation();
            Lin.Root();
            Console.WriteLine("Число x = " + Lin.x);
            Console.ReadKey();
        }
    }
}

struct Equation
{
    public double k;
    public double b;
    public double x;

    public void Root()
    {
        Console.WriteLine("Введите число k = ");
        k = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Введите число b = ");
        b = Convert.ToDouble(Console.ReadLine());
        if (b == 0) { Console.WriteLine("Деление на 0 исключено"); }
        else { x = -(b / k); }
    }

}
